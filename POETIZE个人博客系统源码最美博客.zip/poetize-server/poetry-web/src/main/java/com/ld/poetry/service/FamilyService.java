package com.ld.poetry.service;

import com.ld.poetry.entity.Family;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 家庭信息 服务类
 * </p>
 *
 * @author sara
 * @since 2023-01-03
 */
public interface FamilyService extends IService<Family> {

}
